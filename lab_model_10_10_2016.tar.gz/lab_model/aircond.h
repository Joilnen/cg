#ifndef AIRCOND_H
#define AIRCOND_H

void drawAircond();

#endif
