#ifndef CUBE_H
#define CUBE_H

void drawCube();

#endif
