#ifndef DOOR_H
#define DOOR_H

void drawDoor();

#endif
