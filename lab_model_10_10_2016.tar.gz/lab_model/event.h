#ifndef EVENT_H
#define EVENT_H

#include "app_state_and_events.h"

bool event(AppStateAndEvents &ae);

#endif
