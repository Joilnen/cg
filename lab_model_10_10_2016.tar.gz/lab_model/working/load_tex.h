#ifndef LOAD_TEX_H
#define LOAD_TEX_H

void loadTex();

enum TEX_NAMES {DOOR = 1, WALL_OUT, WALL_IN, CEILING, TEX_NUMBER};

#endif
