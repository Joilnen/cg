#include <GL/gl.h>
#include <GL/glu.h>
#include "press.h"
#include "cube.h"

void drawPress() {
    extern float col_aircond[3];
    extern GLuint m;

    glColor3f(col_aircond[0], col_aircond[1], col_aircond[2]);

    // Cadeira
    glPushMatrix();

    glTranslatef(68, 20, -20);
    glScalef(30, 30, 30);
    glRotatef(90, 1, 0, 0);
    drawCube();

    glPopMatrix();
}


