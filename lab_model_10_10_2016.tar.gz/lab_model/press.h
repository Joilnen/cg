#ifndef PRESS_H
#define PRESS_H

void drawPress();

#endif
