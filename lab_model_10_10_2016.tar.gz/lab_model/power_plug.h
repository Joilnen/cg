#ifndef POWER_PLUG_H
#define POWER_PLUG_H

void drawPowerPlug();

#endif


