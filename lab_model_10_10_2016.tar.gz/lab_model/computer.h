#ifndef COMPUTER_H
#define COMPUTER_H

void drawComputer();

#endif
