#include <GL/gl.h>
#include <GL/glu.h>

#include "power_plug.h"

void drawPowerPlug() {


}
