#ifndef TABLE_H
#define TABLE_H

void drawTable();

#endif

